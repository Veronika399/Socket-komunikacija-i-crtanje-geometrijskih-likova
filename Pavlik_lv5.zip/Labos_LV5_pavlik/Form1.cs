﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;

namespace Labos_LV5_pavlik
{
    public partial class Form1 : Form
    {
        TcpClient client;
        NetworkStream ns;

        Random rand = new Random();
        string[] boje = { "red", "blue", "black", "green", "yellow", "white" };
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            client = new TcpClient(textBoxHostName.Text, int.Parse(textBoxHostPort.Text));
            ns = client.GetStream();
            panel1.BackColor= Color.Green;
        }

        private void btnCloseConnect_Click(object sender, EventArgs e)
        {
            
            client.Close();
            panel1.BackColor = Color.Red;
        }

        private void btnRandomLinija_Click(object sender, EventArgs e)
        {
            textBoxLx1.Text = rand.Next(0, 700).ToString();
            textBoxLy1.Text = rand.Next(0, 500).ToString();
            textBoxLx2.Text = rand.Next(0, 700).ToString();
            textBoxLy2.Text = rand.Next(0, 500).ToString();

            int r = rand.Next(boje.Length);
            string randomColor = ((string)boje[r]);
            txtBoxLColor.Text = randomColor;
        }

        private void btn_RandomTrokut_Click(object sender, EventArgs e)
        {
            textBoxTx1.Text = rand.Next(0, 700).ToString();
            textBoxTy1.Text = rand.Next(0, 500).ToString();
            textBoxTx2.Text = rand.Next(0, 700).ToString();
            textBoxTy2.Text = rand.Next(0, 500).ToString();
            textBoxTx3.Text = rand.Next(0, 700).ToString();
            textBoxTy3.Text = rand.Next(0, 500).ToString();

            int r = rand.Next(boje.Length);
            string randomColor = ((string)boje[r]);
            txtBoxTColor.Text = randomColor;
        }

        private void btn_RandomPravokutnik_Click(object sender, EventArgs e)
        {
            textBoxPRx1.Text = rand.Next(0, 700).ToString();
            textBoxPRy1.Text = rand.Next(0, 500).ToString();
            textBoxPRvisina.Text = rand.Next(0, 200).ToString();
            textBoxPRsirina.Text= rand.Next(0, 100).ToString();

            int r = rand.Next(boje.Length);
            string randomColor = ((string)boje[r]);
            textBoxPRColor.Text = randomColor;
        }

        private void btn_RandomKruznica_Click(object sender, EventArgs e)
        {
            textBoxKX.Text = rand.Next(100, 600).ToString();
            textBoxKY.Text = rand.Next(100, 300).ToString();
            textBoxKR.Text = rand.Next(0, 100).ToString();

            int r = rand.Next(boje.Length);
            string randomColor = ((string)boje[r]);
            textBoxKColor.Text = randomColor;
        }

        private void btn_RandomElipsa_Click(object sender, EventArgs e)
        {
            textBoxEx.Text = rand.Next(200, 700).ToString();
            textBoxEy.Text = rand.Next(200, 500).ToString();
            textBoxEr1.Text = rand.Next(0, 100).ToString();
            textBoxEr2.Text = rand.Next(0, 100).ToString();

            int r = rand.Next(boje.Length);
            string randomColor = ((string)boje[r]);
            textBoxEColor.Text = randomColor;
        }

        private void SendLinija_Click(object sender, EventArgs e)
        {
            string send = "Line " + txtBoxLColor.Text +" "+ textBoxLx1.Text +" "+ textBoxLy1.Text +" "+ textBoxLx2.Text +" "+ textBoxLy2.Text;
            Console.WriteLine(send);
            int byteCount = Encoding.ASCII.GetByteCount(send); 
            byte[] sendData = new byte[byteCount]; 
            sendData = Encoding.ASCII.GetBytes(send); 
            NetworkStream stream = client.GetStream(); 
            stream.Write(sendData, 0, sendData.Length); 
        }

        private void SendTrokut_Click(object sender, EventArgs e)
        {
            string send = "Triangle " + txtBoxTColor.Text + " " + textBoxTx1.Text + " " + textBoxTy1.Text + " " + textBoxTx2.Text + " " + textBoxTy2.Text+" "+ textBoxTx3.Text+" "+ textBoxTy3.Text;
            Console.WriteLine(send);
            int byteCount = Encoding.ASCII.GetByteCount(send); 
            byte[] sendData = new byte[byteCount]; 
            sendData = Encoding.ASCII.GetBytes(send); 
            NetworkStream stream = client.GetStream(); 
            stream.Write(sendData, 0, sendData.Length); 
        }

        private void SendPravokutnik_Click(object sender, EventArgs e)
        {
            string send = "Rectangle " + textBoxPRColor.Text + " " + textBoxPRx1.Text + " " + textBoxPRy1.Text + " " + textBoxPRvisina.Text + " " + textBoxPRsirina.Text;
            Console.WriteLine(send);
            int byteCount = Encoding.ASCII.GetByteCount(send); 
            byte[] sendData = new byte[byteCount]; 
            sendData = Encoding.ASCII.GetBytes(send); 
            NetworkStream stream = client.GetStream(); 
            stream.Write(sendData, 0, sendData.Length); 
        }

        private void SendKruznica_Click(object sender, EventArgs e)
        {
            string send = "Circle " + textBoxKColor.Text +" "+ textBoxKX.Text +" "+ textBoxKY.Text + " " + textBoxKR.Text;
            Console.WriteLine(send);
            int byteCount = Encoding.ASCII.GetByteCount(send); 
            byte[] sendData = new byte[byteCount]; 
            sendData = Encoding.ASCII.GetBytes(send); 
            NetworkStream stream = client.GetStream(); 
            stream.Write(sendData, 0, sendData.Length); 
        }

        private void SendElipsa_Click(object sender, EventArgs e)
        {
            string send = "Ellipse " + textBoxEColor.Text + " " + textBoxEx.Text + " " + textBoxEy.Text + " " + textBoxEr1.Text+" "+ textBoxEr2.Text;
            Console.WriteLine(send);
            int byteCount = Encoding.ASCII.GetByteCount(send); 
            byte[] sendData = new byte[byteCount]; 
            sendData = Encoding.ASCII.GetBytes(send); 
            NetworkStream stream = client.GetStream(); 
            stream.Write(sendData, 0, sendData.Length); 
        }
    }
}
