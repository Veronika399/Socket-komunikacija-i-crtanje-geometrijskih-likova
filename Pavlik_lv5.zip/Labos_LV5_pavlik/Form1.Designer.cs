﻿namespace Labos_LV5_pavlik
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnCloseConnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.textBoxHostPort = new System.Windows.Forms.TextBox();
            this.textBoxHostName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.SendLinija = new System.Windows.Forms.Button();
            this.btnRandomLinija = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtBoxLColor = new System.Windows.Forms.TextBox();
            this.textBoxLy2 = new System.Windows.Forms.TextBox();
            this.textBoxLx2 = new System.Windows.Forms.TextBox();
            this.textBoxLy1 = new System.Windows.Forms.TextBox();
            this.textBoxLx1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.SendTrokut = new System.Windows.Forms.Button();
            this.btn_RandomTrokut = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtBoxTColor = new System.Windows.Forms.TextBox();
            this.textBoxTy3 = new System.Windows.Forms.TextBox();
            this.textBoxTx3 = new System.Windows.Forms.TextBox();
            this.textBoxTy2 = new System.Windows.Forms.TextBox();
            this.textBoxTx2 = new System.Windows.Forms.TextBox();
            this.textBoxTy1 = new System.Windows.Forms.TextBox();
            this.textBoxTx1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.SendPravokutnik = new System.Windows.Forms.Button();
            this.btn_RandomPravokutnik = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxPRColor = new System.Windows.Forms.TextBox();
            this.textBoxPRsirina = new System.Windows.Forms.TextBox();
            this.textBoxPRvisina = new System.Windows.Forms.TextBox();
            this.textBoxPRy1 = new System.Windows.Forms.TextBox();
            this.textBoxPRx1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btn_RandomPolygon = new System.Windows.Forms.Button();
            this.SendPolygon = new System.Windows.Forms.Button();
            this.add_point = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxPOColor = new System.Windows.Forms.TextBox();
            this.listBoxAllYPoint = new System.Windows.Forms.ListBox();
            this.listBoxAllXPoint = new System.Windows.Forms.ListBox();
            this.listBoxAllPoint = new System.Windows.Forms.ListBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.SendKruznica = new System.Windows.Forms.Button();
            this.btn_RandomKruznica = new System.Windows.Forms.Button();
            this.textBoxKColor = new System.Windows.Forms.TextBox();
            this.textBoxKR = new System.Windows.Forms.TextBox();
            this.textBoxKY = new System.Windows.Forms.TextBox();
            this.textBoxKX = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.SendElipsa = new System.Windows.Forms.Button();
            this.btn_RandomElipsa = new System.Windows.Forms.Button();
            this.textBoxEColor = new System.Windows.Forms.TextBox();
            this.textBoxEr2 = new System.Windows.Forms.TextBox();
            this.textBoxEr1 = new System.Windows.Forms.TextBox();
            this.textBoxEy = new System.Windows.Forms.TextBox();
            this.textBoxEx = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Location = new System.Drawing.Point(10, 11);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(466, 338);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.btnConnect_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnCloseConnect);
            this.tabPage1.Controls.Add(this.btnConnect);
            this.tabPage1.Controls.Add(this.textBoxHostPort);
            this.tabPage1.Controls.Add(this.textBoxHostName);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(458, 312);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Connect";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnCloseConnect
            // 
            this.btnCloseConnect.Location = new System.Drawing.Point(215, 206);
            this.btnCloseConnect.Margin = new System.Windows.Forms.Padding(2);
            this.btnCloseConnect.Name = "btnCloseConnect";
            this.btnCloseConnect.Size = new System.Drawing.Size(104, 19);
            this.btnCloseConnect.TabIndex = 5;
            this.btnCloseConnect.Text = "Close connect";
            this.btnCloseConnect.UseVisualStyleBackColor = true;
            this.btnCloseConnect.Click += new System.EventHandler(this.btnCloseConnect_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.Transparent;
            this.btnConnect.Location = new System.Drawing.Point(101, 207);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(2);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(56, 19);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // textBoxHostPort
            // 
            this.textBoxHostPort.Location = new System.Drawing.Point(101, 67);
            this.textBoxHostPort.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxHostPort.Name = "textBoxHostPort";
            this.textBoxHostPort.Size = new System.Drawing.Size(76, 20);
            this.textBoxHostPort.TabIndex = 3;
            this.textBoxHostPort.Text = "8000";
            // 
            // textBoxHostName
            // 
            this.textBoxHostName.Location = new System.Drawing.Point(101, 22);
            this.textBoxHostName.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxHostName.Name = "textBoxHostName";
            this.textBoxHostName.Size = new System.Drawing.Size(76, 20);
            this.textBoxHostName.TabIndex = 2;
            this.textBoxHostName.Text = "localhost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Host port";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Host name";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.SendLinija);
            this.tabPage2.Controls.Add(this.btnRandomLinija);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtBoxLColor);
            this.tabPage2.Controls.Add(this.textBoxLy2);
            this.tabPage2.Controls.Add(this.textBoxLx2);
            this.tabPage2.Controls.Add(this.textBoxLy1);
            this.tabPage2.Controls.Add(this.textBoxLx1);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(458, 312);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Linija";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // SendLinija
            // 
            this.SendLinija.Location = new System.Drawing.Point(173, 188);
            this.SendLinija.Margin = new System.Windows.Forms.Padding(2);
            this.SendLinija.Name = "SendLinija";
            this.SendLinija.Size = new System.Drawing.Size(114, 37);
            this.SendLinija.TabIndex = 11;
            this.SendLinija.Text = "Send";
            this.SendLinija.UseVisualStyleBackColor = true;
            this.SendLinija.Click += new System.EventHandler(this.SendLinija_Click);
            // 
            // btnRandomLinija
            // 
            this.btnRandomLinija.Location = new System.Drawing.Point(208, 95);
            this.btnRandomLinija.Margin = new System.Windows.Forms.Padding(2);
            this.btnRandomLinija.Name = "btnRandomLinija";
            this.btnRandomLinija.Size = new System.Drawing.Size(68, 19);
            this.btnRandomLinija.TabIndex = 10;
            this.btnRandomLinija.Text = "Random";
            this.btnRandomLinija.UseVisualStyleBackColor = true;
            this.btnRandomLinija.Click += new System.EventHandler(this.btnRandomLinija_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(206, 43);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Boja:";
            // 
            // txtBoxLColor
            // 
            this.txtBoxLColor.Location = new System.Drawing.Point(239, 41);
            this.txtBoxLColor.Margin = new System.Windows.Forms.Padding(2);
            this.txtBoxLColor.Name = "txtBoxLColor";
            this.txtBoxLColor.Size = new System.Drawing.Size(134, 20);
            this.txtBoxLColor.TabIndex = 8;
            // 
            // textBoxLy2
            // 
            this.textBoxLy2.Location = new System.Drawing.Point(70, 93);
            this.textBoxLy2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLy2.Name = "textBoxLy2";
            this.textBoxLy2.Size = new System.Drawing.Size(76, 20);
            this.textBoxLy2.TabIndex = 7;
            // 
            // textBoxLx2
            // 
            this.textBoxLx2.Location = new System.Drawing.Point(71, 67);
            this.textBoxLx2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLx2.Name = "textBoxLx2";
            this.textBoxLx2.Size = new System.Drawing.Size(76, 20);
            this.textBoxLx2.TabIndex = 6;
            // 
            // textBoxLy1
            // 
            this.textBoxLy1.Location = new System.Drawing.Point(71, 41);
            this.textBoxLy1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLy1.Name = "textBoxLy1";
            this.textBoxLy1.Size = new System.Drawing.Size(76, 20);
            this.textBoxLy1.TabIndex = 5;
            // 
            // textBoxLx1
            // 
            this.textBoxLx1.Location = new System.Drawing.Point(71, 13);
            this.textBoxLx1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLx1.Name = "textBoxLx1";
            this.textBoxLx1.Size = new System.Drawing.Size(76, 20);
            this.textBoxLx1.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 95);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Tocka 2-Y";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 67);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tocka 2-X";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 41);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Tocka 1-Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 13);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Tocka 1-X";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.SendTrokut);
            this.tabPage3.Controls.Add(this.btn_RandomTrokut);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.txtBoxTColor);
            this.tabPage3.Controls.Add(this.textBoxTy3);
            this.tabPage3.Controls.Add(this.textBoxTx3);
            this.tabPage3.Controls.Add(this.textBoxTy2);
            this.tabPage3.Controls.Add(this.textBoxTx2);
            this.tabPage3.Controls.Add(this.textBoxTy1);
            this.tabPage3.Controls.Add(this.textBoxTx1);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage3.Size = new System.Drawing.Size(458, 312);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Trokut";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // SendTrokut
            // 
            this.SendTrokut.Location = new System.Drawing.Point(196, 232);
            this.SendTrokut.Margin = new System.Windows.Forms.Padding(2);
            this.SendTrokut.Name = "SendTrokut";
            this.SendTrokut.Size = new System.Drawing.Size(76, 32);
            this.SendTrokut.TabIndex = 15;
            this.SendTrokut.Text = "Send";
            this.SendTrokut.UseVisualStyleBackColor = true;
            this.SendTrokut.Click += new System.EventHandler(this.SendTrokut_Click);
            // 
            // btn_RandomTrokut
            // 
            this.btn_RandomTrokut.Location = new System.Drawing.Point(232, 133);
            this.btn_RandomTrokut.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RandomTrokut.Name = "btn_RandomTrokut";
            this.btn_RandomTrokut.Size = new System.Drawing.Size(80, 19);
            this.btn_RandomTrokut.TabIndex = 14;
            this.btn_RandomTrokut.Text = "Random";
            this.btn_RandomTrokut.UseVisualStyleBackColor = true;
            this.btn_RandomTrokut.Click += new System.EventHandler(this.btn_RandomTrokut_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(230, 50);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Boja";
            // 
            // txtBoxTColor
            // 
            this.txtBoxTColor.Location = new System.Drawing.Point(281, 47);
            this.txtBoxTColor.Margin = new System.Windows.Forms.Padding(2);
            this.txtBoxTColor.Name = "txtBoxTColor";
            this.txtBoxTColor.Size = new System.Drawing.Size(144, 20);
            this.txtBoxTColor.TabIndex = 12;
            // 
            // textBoxTy3
            // 
            this.textBoxTy3.Location = new System.Drawing.Point(72, 180);
            this.textBoxTy3.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTy3.Name = "textBoxTy3";
            this.textBoxTy3.Size = new System.Drawing.Size(76, 20);
            this.textBoxTy3.TabIndex = 11;
            // 
            // textBoxTx3
            // 
            this.textBoxTx3.Location = new System.Drawing.Point(72, 144);
            this.textBoxTx3.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTx3.Name = "textBoxTx3";
            this.textBoxTx3.Size = new System.Drawing.Size(76, 20);
            this.textBoxTx3.TabIndex = 10;
            // 
            // textBoxTy2
            // 
            this.textBoxTy2.Location = new System.Drawing.Point(72, 106);
            this.textBoxTy2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTy2.Name = "textBoxTy2";
            this.textBoxTy2.Size = new System.Drawing.Size(76, 20);
            this.textBoxTy2.TabIndex = 9;
            // 
            // textBoxTx2
            // 
            this.textBoxTx2.Location = new System.Drawing.Point(72, 77);
            this.textBoxTx2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTx2.Name = "textBoxTx2";
            this.textBoxTx2.Size = new System.Drawing.Size(76, 20);
            this.textBoxTx2.TabIndex = 8;
            // 
            // textBoxTy1
            // 
            this.textBoxTy1.Location = new System.Drawing.Point(72, 45);
            this.textBoxTy1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTy1.Name = "textBoxTy1";
            this.textBoxTy1.Size = new System.Drawing.Size(76, 20);
            this.textBoxTy1.TabIndex = 7;
            // 
            // textBoxTx1
            // 
            this.textBoxTx1.Location = new System.Drawing.Point(72, 15);
            this.textBoxTx1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTx1.Name = "textBoxTx1";
            this.textBoxTx1.Size = new System.Drawing.Size(76, 20);
            this.textBoxTx1.TabIndex = 6;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 184);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 5;
            this.label14.Text = "Točka 3-Y";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 146);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Točka 3-X";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 109);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 3;
            this.label12.Text = "Točka 2-Y";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 80);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 2;
            this.label11.Text = "Točka 2-X";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 47);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Točka 1-Y";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 17);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Točka 1-X";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.SendPravokutnik);
            this.tabPage4.Controls.Add(this.btn_RandomPravokutnik);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.textBoxPRColor);
            this.tabPage4.Controls.Add(this.textBoxPRsirina);
            this.tabPage4.Controls.Add(this.textBoxPRvisina);
            this.tabPage4.Controls.Add(this.textBoxPRy1);
            this.tabPage4.Controls.Add(this.textBoxPRx1);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage4.Size = new System.Drawing.Size(458, 312);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Pravokutnik";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // SendPravokutnik
            // 
            this.SendPravokutnik.Location = new System.Drawing.Point(190, 197);
            this.SendPravokutnik.Margin = new System.Windows.Forms.Padding(2);
            this.SendPravokutnik.Name = "SendPravokutnik";
            this.SendPravokutnik.Size = new System.Drawing.Size(126, 29);
            this.SendPravokutnik.TabIndex = 11;
            this.SendPravokutnik.Text = "Send";
            this.SendPravokutnik.UseVisualStyleBackColor = true;
            this.SendPravokutnik.Click += new System.EventHandler(this.SendPravokutnik_Click);
            // 
            // btn_RandomPravokutnik
            // 
            this.btn_RandomPravokutnik.Location = new System.Drawing.Point(280, 87);
            this.btn_RandomPravokutnik.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RandomPravokutnik.Name = "btn_RandomPravokutnik";
            this.btn_RandomPravokutnik.Size = new System.Drawing.Size(68, 29);
            this.btn_RandomPravokutnik.TabIndex = 10;
            this.btn_RandomPravokutnik.Text = "Random";
            this.btn_RandomPravokutnik.UseVisualStyleBackColor = true;
            this.btn_RandomPravokutnik.Click += new System.EventHandler(this.btn_RandomPravokutnik_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(242, 45);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(28, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Boja";
            // 
            // textBoxPRColor
            // 
            this.textBoxPRColor.Location = new System.Drawing.Point(280, 40);
            this.textBoxPRColor.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPRColor.Name = "textBoxPRColor";
            this.textBoxPRColor.Size = new System.Drawing.Size(138, 20);
            this.textBoxPRColor.TabIndex = 8;
            // 
            // textBoxPRsirina
            // 
            this.textBoxPRsirina.Location = new System.Drawing.Point(83, 120);
            this.textBoxPRsirina.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPRsirina.Name = "textBoxPRsirina";
            this.textBoxPRsirina.Size = new System.Drawing.Size(76, 20);
            this.textBoxPRsirina.TabIndex = 7;
            // 
            // textBoxPRvisina
            // 
            this.textBoxPRvisina.Location = new System.Drawing.Point(83, 87);
            this.textBoxPRvisina.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPRvisina.Name = "textBoxPRvisina";
            this.textBoxPRvisina.Size = new System.Drawing.Size(76, 20);
            this.textBoxPRvisina.TabIndex = 6;
            // 
            // textBoxPRy1
            // 
            this.textBoxPRy1.Location = new System.Drawing.Point(83, 52);
            this.textBoxPRy1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPRy1.Name = "textBoxPRy1";
            this.textBoxPRy1.Size = new System.Drawing.Size(76, 20);
            this.textBoxPRy1.TabIndex = 5;
            // 
            // textBoxPRx1
            // 
            this.textBoxPRx1.Location = new System.Drawing.Point(83, 16);
            this.textBoxPRx1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPRx1.Name = "textBoxPRx1";
            this.textBoxPRx1.Size = new System.Drawing.Size(76, 20);
            this.textBoxPRx1.TabIndex = 4;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(16, 120);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 13);
            this.label19.TabIndex = 3;
            this.label19.Text = "Širina";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 87);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 13);
            this.label18.TabIndex = 2;
            this.label18.Text = "Visina";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(14, 52);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 13);
            this.label17.TabIndex = 1;
            this.label17.Text = "Položaj - Y";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 16);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Položaj - X";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btn_RandomPolygon);
            this.tabPage5.Controls.Add(this.SendPolygon);
            this.tabPage5.Controls.Add(this.add_point);
            this.tabPage5.Controls.Add(this.label23);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.label21);
            this.tabPage5.Controls.Add(this.textBoxPOColor);
            this.tabPage5.Controls.Add(this.listBoxAllYPoint);
            this.tabPage5.Controls.Add(this.listBoxAllXPoint);
            this.tabPage5.Controls.Add(this.listBoxAllPoint);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage5.Size = new System.Drawing.Size(458, 312);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Polygon";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btn_RandomPolygon
            // 
            this.btn_RandomPolygon.Location = new System.Drawing.Point(21, 166);
            this.btn_RandomPolygon.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RandomPolygon.Name = "btn_RandomPolygon";
            this.btn_RandomPolygon.Size = new System.Drawing.Size(85, 24);
            this.btn_RandomPolygon.TabIndex = 9;
            this.btn_RandomPolygon.Text = "Random";
            this.btn_RandomPolygon.UseVisualStyleBackColor = true;
            // 
            // SendPolygon
            // 
            this.SendPolygon.Location = new System.Drawing.Point(178, 240);
            this.SendPolygon.Margin = new System.Windows.Forms.Padding(2);
            this.SendPolygon.Name = "SendPolygon";
            this.SendPolygon.Size = new System.Drawing.Size(99, 31);
            this.SendPolygon.TabIndex = 8;
            this.SendPolygon.Text = "Send";
            this.SendPolygon.UseVisualStyleBackColor = true;
            // 
            // add_point
            // 
            this.add_point.Location = new System.Drawing.Point(226, 117);
            this.add_point.Margin = new System.Windows.Forms.Padding(2);
            this.add_point.Name = "add_point";
            this.add_point.Size = new System.Drawing.Size(105, 25);
            this.add_point.TabIndex = 7;
            this.add_point.Text = "Add point";
            this.add_point.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(176, 167);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = "Boja";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(175, 65);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(54, 13);
            this.label22.TabIndex = 5;
            this.label22.Text = "Tocka - Y";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(174, 16);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Tocka - X";
            // 
            // textBoxPOColor
            // 
            this.textBoxPOColor.Location = new System.Drawing.Point(226, 167);
            this.textBoxPOColor.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPOColor.Name = "textBoxPOColor";
            this.textBoxPOColor.Size = new System.Drawing.Size(106, 20);
            this.textBoxPOColor.TabIndex = 3;
            // 
            // listBoxAllYPoint
            // 
            this.listBoxAllYPoint.FormattingEnabled = true;
            this.listBoxAllYPoint.Location = new System.Drawing.Point(232, 65);
            this.listBoxAllYPoint.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxAllYPoint.Name = "listBoxAllYPoint";
            this.listBoxAllYPoint.Size = new System.Drawing.Size(106, 30);
            this.listBoxAllYPoint.TabIndex = 2;
            // 
            // listBoxAllXPoint
            // 
            this.listBoxAllXPoint.FormattingEnabled = true;
            this.listBoxAllXPoint.Location = new System.Drawing.Point(232, 16);
            this.listBoxAllXPoint.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxAllXPoint.Name = "listBoxAllXPoint";
            this.listBoxAllXPoint.Size = new System.Drawing.Size(106, 30);
            this.listBoxAllXPoint.TabIndex = 1;
            // 
            // listBoxAllPoint
            // 
            this.listBoxAllPoint.FormattingEnabled = true;
            this.listBoxAllPoint.Location = new System.Drawing.Point(14, 16);
            this.listBoxAllPoint.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxAllPoint.Name = "listBoxAllPoint";
            this.listBoxAllPoint.Size = new System.Drawing.Size(92, 121);
            this.listBoxAllPoint.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.SendKruznica);
            this.tabPage6.Controls.Add(this.btn_RandomKruznica);
            this.tabPage6.Controls.Add(this.textBoxKColor);
            this.tabPage6.Controls.Add(this.textBoxKR);
            this.tabPage6.Controls.Add(this.textBoxKY);
            this.tabPage6.Controls.Add(this.textBoxKX);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage6.Size = new System.Drawing.Size(458, 312);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Kružnica";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // SendKruznica
            // 
            this.SendKruznica.Location = new System.Drawing.Point(188, 193);
            this.SendKruznica.Margin = new System.Windows.Forms.Padding(2);
            this.SendKruznica.Name = "SendKruznica";
            this.SendKruznica.Size = new System.Drawing.Size(92, 41);
            this.SendKruznica.TabIndex = 10;
            this.SendKruznica.Text = "Send";
            this.SendKruznica.UseVisualStyleBackColor = true;
            this.SendKruznica.Click += new System.EventHandler(this.SendKruznica_Click);
            // 
            // btn_RandomKruznica
            // 
            this.btn_RandomKruznica.Location = new System.Drawing.Point(272, 67);
            this.btn_RandomKruznica.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RandomKruznica.Name = "btn_RandomKruznica";
            this.btn_RandomKruznica.Size = new System.Drawing.Size(92, 33);
            this.btn_RandomKruznica.TabIndex = 9;
            this.btn_RandomKruznica.Text = "Random";
            this.btn_RandomKruznica.UseVisualStyleBackColor = true;
            this.btn_RandomKruznica.Click += new System.EventHandler(this.btn_RandomKruznica_Click);
            // 
            // textBoxKColor
            // 
            this.textBoxKColor.Location = new System.Drawing.Point(272, 20);
            this.textBoxKColor.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxKColor.Name = "textBoxKColor";
            this.textBoxKColor.Size = new System.Drawing.Size(111, 20);
            this.textBoxKColor.TabIndex = 8;
            // 
            // textBoxKR
            // 
            this.textBoxKR.Location = new System.Drawing.Point(70, 87);
            this.textBoxKR.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxKR.Name = "textBoxKR";
            this.textBoxKR.Size = new System.Drawing.Size(76, 20);
            this.textBoxKR.TabIndex = 7;
            // 
            // textBoxKY
            // 
            this.textBoxKY.Location = new System.Drawing.Point(70, 54);
            this.textBoxKY.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxKY.Name = "textBoxKY";
            this.textBoxKY.Size = new System.Drawing.Size(76, 20);
            this.textBoxKY.TabIndex = 5;
            // 
            // textBoxKX
            // 
            this.textBoxKX.Location = new System.Drawing.Point(70, 20);
            this.textBoxKX.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxKX.Name = "textBoxKX";
            this.textBoxKX.Size = new System.Drawing.Size(76, 20);
            this.textBoxKX.TabIndex = 4;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(229, 20);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(28, 13);
            this.label27.TabIndex = 3;
            this.label27.Text = "Boja";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(16, 87);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(42, 13);
            this.label26.TabIndex = 2;
            this.label26.Text = "Radijus";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(16, 54);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(54, 13);
            this.label25.TabIndex = 1;
            this.label25.Text = "Centar - Y";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(16, 20);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(54, 13);
            this.label24.TabIndex = 0;
            this.label24.Text = "Centar - X";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.SendElipsa);
            this.tabPage7.Controls.Add(this.btn_RandomElipsa);
            this.tabPage7.Controls.Add(this.textBoxEColor);
            this.tabPage7.Controls.Add(this.textBoxEr2);
            this.tabPage7.Controls.Add(this.textBoxEr1);
            this.tabPage7.Controls.Add(this.textBoxEy);
            this.tabPage7.Controls.Add(this.textBoxEx);
            this.tabPage7.Controls.Add(this.label32);
            this.tabPage7.Controls.Add(this.label31);
            this.tabPage7.Controls.Add(this.label30);
            this.tabPage7.Controls.Add(this.label29);
            this.tabPage7.Controls.Add(this.label28);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage7.Size = new System.Drawing.Size(458, 312);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Elipsa";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // SendElipsa
            // 
            this.SendElipsa.Location = new System.Drawing.Point(176, 197);
            this.SendElipsa.Margin = new System.Windows.Forms.Padding(2);
            this.SendElipsa.Name = "SendElipsa";
            this.SendElipsa.Size = new System.Drawing.Size(68, 29);
            this.SendElipsa.TabIndex = 11;
            this.SendElipsa.Text = "Send";
            this.SendElipsa.UseVisualStyleBackColor = true;
            this.SendElipsa.Click += new System.EventHandler(this.SendElipsa_Click);
            // 
            // btn_RandomElipsa
            // 
            this.btn_RandomElipsa.Location = new System.Drawing.Point(238, 67);
            this.btn_RandomElipsa.Margin = new System.Windows.Forms.Padding(2);
            this.btn_RandomElipsa.Name = "btn_RandomElipsa";
            this.btn_RandomElipsa.Size = new System.Drawing.Size(85, 33);
            this.btn_RandomElipsa.TabIndex = 10;
            this.btn_RandomElipsa.Text = "Random";
            this.btn_RandomElipsa.UseVisualStyleBackColor = true;
            this.btn_RandomElipsa.Click += new System.EventHandler(this.btn_RandomElipsa_Click);
            // 
            // textBoxEColor
            // 
            this.textBoxEColor.Location = new System.Drawing.Point(261, 16);
            this.textBoxEColor.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEColor.Name = "textBoxEColor";
            this.textBoxEColor.Size = new System.Drawing.Size(76, 20);
            this.textBoxEColor.TabIndex = 9;
            // 
            // textBoxEr2
            // 
            this.textBoxEr2.Location = new System.Drawing.Point(67, 120);
            this.textBoxEr2.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEr2.Name = "textBoxEr2";
            this.textBoxEr2.Size = new System.Drawing.Size(76, 20);
            this.textBoxEr2.TabIndex = 8;
            // 
            // textBoxEr1
            // 
            this.textBoxEr1.Location = new System.Drawing.Point(67, 87);
            this.textBoxEr1.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEr1.Name = "textBoxEr1";
            this.textBoxEr1.Size = new System.Drawing.Size(76, 20);
            this.textBoxEr1.TabIndex = 7;
            // 
            // textBoxEy
            // 
            this.textBoxEy.Location = new System.Drawing.Point(67, 52);
            this.textBoxEy.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEy.Name = "textBoxEy";
            this.textBoxEy.Size = new System.Drawing.Size(76, 20);
            this.textBoxEy.TabIndex = 6;
            // 
            // textBoxEx
            // 
            this.textBoxEx.Location = new System.Drawing.Point(67, 15);
            this.textBoxEx.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEx.Name = "textBoxEx";
            this.textBoxEx.Size = new System.Drawing.Size(76, 20);
            this.textBoxEx.TabIndex = 5;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(218, 17);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(28, 13);
            this.label32.TabIndex = 4;
            this.label32.Text = "Boja";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 123);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(51, 13);
            this.label31.TabIndex = 3;
            this.label31.Text = "Radijus 2";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(14, 87);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 13);
            this.label30.TabIndex = 2;
            this.label30.Text = "Radijus 1";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(14, 54);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(54, 13);
            this.label29.TabIndex = 1;
            this.label29.Text = "Centar - Y";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(14, 17);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(54, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "Centar - X";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(518, 118);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(150, 139);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(550, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Connection status:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 362);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnCloseConnect;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox textBoxHostPort;
        private System.Windows.Forms.TextBox textBoxHostName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button SendLinija;
        private System.Windows.Forms.Button btnRandomLinija;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtBoxLColor;
        private System.Windows.Forms.TextBox textBoxLy2;
        private System.Windows.Forms.TextBox textBoxLx2;
        private System.Windows.Forms.TextBox textBoxLy1;
        private System.Windows.Forms.TextBox textBoxLx1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtBoxTColor;
        private System.Windows.Forms.TextBox textBoxTy3;
        private System.Windows.Forms.TextBox textBoxTx3;
        private System.Windows.Forms.TextBox textBoxTy2;
        private System.Windows.Forms.TextBox textBoxTx2;
        private System.Windows.Forms.TextBox textBoxTy1;
        private System.Windows.Forms.TextBox textBoxTx1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button SendTrokut;
        private System.Windows.Forms.Button btn_RandomTrokut;
        private System.Windows.Forms.Button SendPravokutnik;
        private System.Windows.Forms.Button btn_RandomPravokutnik;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxPRColor;
        private System.Windows.Forms.TextBox textBoxPRsirina;
        private System.Windows.Forms.TextBox textBoxPRvisina;
        private System.Windows.Forms.TextBox textBoxPRy1;
        private System.Windows.Forms.TextBox textBoxPRx1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btn_RandomPolygon;
        private System.Windows.Forms.Button SendPolygon;
        private System.Windows.Forms.Button add_point;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxPOColor;
        private System.Windows.Forms.ListBox listBoxAllYPoint;
        private System.Windows.Forms.ListBox listBoxAllXPoint;
        private System.Windows.Forms.ListBox listBoxAllPoint;
        private System.Windows.Forms.Button SendKruznica;
        private System.Windows.Forms.Button btn_RandomKruznica;
        private System.Windows.Forms.TextBox textBoxKColor;
        private System.Windows.Forms.TextBox textBoxKR;
        private System.Windows.Forms.TextBox textBoxKY;
        private System.Windows.Forms.TextBox textBoxKX;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button SendElipsa;
        private System.Windows.Forms.Button btn_RandomElipsa;
        private System.Windows.Forms.TextBox textBoxEColor;
        private System.Windows.Forms.TextBox textBoxEr2;
        private System.Windows.Forms.TextBox textBoxEr1;
        private System.Windows.Forms.TextBox textBoxEy;
        private System.Windows.Forms.TextBox textBoxEx;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
    }
}

